from rest_framework import serializers
from .models import Movie
from authenticate.models import User

class MovieSerializer(serializers.ModelSerializer):
    class Meta:
        model = Movie
        fields = '__all__'
    
class FavSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['favourite']